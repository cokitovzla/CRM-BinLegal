import React, { useState } from 'react';
import { BINLEGAL_TEAM } from '../data/initialData';
import { TeamMember } from '../types';
import { Award, Briefcase, X } from 'lucide-react';

export const TeamSection: React.FC = () => {
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  return (
    <section id="equipo" className="py-10 sm:py-12 lg:py-14 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-6 sm:mb-8">
          <div className="text-[11px] sm:text-xs font-semibold tracking-wider text-[#0071ce] uppercase mb-1.5 sm:mb-2">
            04 — Equipo
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold text-slate-950 tracking-tight mb-2 text-balance">
            Abogados especializados, obsesionados con tu crecimiento.
          </h2>
          <p className="text-xs sm:text-sm lg:text-base text-slate-600 leading-relaxed">
            Combinamos rigor técnico con mentalidad emprendedora. Entendemos la presión del flujo de caja, la urgencia de cerrar contratos y el valor de no perder tiempo en burocracia estéril.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {BINLEGAL_TEAM.map((member) => {
            const isFounder = member.id === 'jose-rafael-vasquez';
            return (
              <div
                key={member.id}
                onClick={() => setSelectedMember(member)}
                className={`rounded-xl p-4 sm:p-5 border transition-all cursor-pointer flex flex-col justify-between group shadow-xs hover:shadow-md active:scale-[0.99] ${
                  isFounder 
                    ? 'border-[#0b192c] ring-1 ring-[#0b192c]/20 bg-gradient-to-b from-slate-50 via-white to-slate-50/50 shadow-sm md:col-span-2 lg:col-span-1' 
                    : 'bg-white border-slate-200/90 hover:border-slate-400'
                }`}
              >
                <div>
                  {/* Avatar Initials Badge & Name */}
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 rounded-xl bg-[#0b192c] text-white flex items-center justify-center font-display font-bold text-base tracking-wider shrink-0 shadow-xs">
                      {member.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-display font-bold text-slate-950 group-hover:text-[#0071ce] transition-colors leading-snug">
                        {member.name}
                      </h3>
                      <div className="text-xs font-semibold text-[#0071ce]">
                        {member.role}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
                    {member.bio}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 text-slate-800 font-medium">
                    <Briefcase className="w-3.5 h-3.5 text-[#0071ce] shrink-0" />
                    <span className="truncate">{member.specialty}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 font-mono">
                    <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{member.experience}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Member Details Modal */}
      {selectedMember && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/50 backdrop-blur-xs animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white w-full max-w-lg rounded-2xl border border-neutral-200 shadow-xl overflow-hidden p-5 sm:p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-display font-bold text-base">
                  {selectedMember.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-display font-extrabold text-neutral-950 leading-tight">
                    {selectedMember.name}
                  </h3>
                  <p className="text-xs text-neutral-500 font-medium">
                    {selectedMember.role}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedMember(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-neutral-700">
              <p className="leading-relaxed">
                {selectedMember.bio}
              </p>

              <div className="p-3 bg-neutral-50 rounded-xl space-y-1.5 border border-neutral-200/80 text-xs">
                <div>
                  <span className="font-semibold text-neutral-900">Especialidad: </span>
                  <span className="text-neutral-600">{selectedMember.specialty}</span>
                </div>
                <div>
                  <span className="font-semibold text-neutral-900">Trayectoria: </span>
                  <span className="text-neutral-600">{selectedMember.experience}</span>
                </div>
                <div>
                  <span className="font-semibold text-neutral-900">Contacto Directo: </span>
                  <a href={`mailto:${selectedMember.email}`} className="text-neutral-900 underline font-mono">
                    {selectedMember.email}
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-neutral-100 flex justify-end">
              <button
                onClick={() => setSelectedMember(null)}
                className="px-4 py-2 text-xs font-semibold bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
