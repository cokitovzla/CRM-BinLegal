import React from 'react';

export const WhySection: React.FC = () => {
  return (
    <section id="por-que" className="py-10 sm:py-12 lg:py-14 bg-[#0B192C] text-white border-b border-slate-800 relative overflow-hidden">
      {/* Subtle background glow */}
      <div 
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #ffffff 1px, transparent 0)`,
          backgroundSize: '32px 32px'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-6 sm:mb-8">
          <div className="text-[11px] sm:text-xs font-semibold tracking-wider text-[#0071ce] uppercase mb-1.5 sm:mb-2">
            02 — Por qué lo hacemos
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold text-white tracking-tight leading-[1.15] mb-2 text-balance">
            Existimos para que tu negocio se vuelva empresa.
          </h2>
          <p className="text-xs sm:text-sm lg:text-base text-slate-300 leading-relaxed">
            La transición de un emprendimiento informal a una compañía escalable y transferible no depende de la suerte, sino del andamiaje legal que sostiene las decisiones diarias.
          </p>
        </div>

        {/* 3 Core Pillars with adjacent documentary visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          
          {/* Visual Editorial Box */}
          <div className="lg:col-span-5 flex flex-col">
            <div className="h-full min-h-[220px] sm:min-h-[260px] lg:min-h-[360px] rounded-xl overflow-hidden border border-slate-700/80 shadow-md relative group flex flex-col justify-end">
              <img
                src="/src/assets/images/team_legal_consultation_1792518328026.jpg"
                alt="Mesa de trabajo y asesoría estratégica BinLegal con clientes"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700 ease-out"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B192C]/95 via-[#0B192C]/50 to-transparent pointer-events-none" />
              
              <div className="relative p-4 sm:p-6 text-white">
                <div className="text-[10px] sm:text-xs font-mono uppercase text-[#0071ce] font-semibold tracking-wider mb-1.5">
                  Caso Real · Impacto Comprobado
                </div>
                <blockquote className="text-xs sm:text-sm font-medium leading-snug text-slate-100">
                  "El 90% de los problemas que atendemos como urgencias en empresas medianas pudieron haberse blindado en una tarde con el pacto de socios inicial."
                </blockquote>
                <div className="mt-3 pt-2.5 border-t border-slate-700/80 flex items-center justify-between text-[11px] text-slate-300">
                  <span>Ricardo Salas · Socio</span>
                  <span className="text-[#0071ce] font-medium">Estrategia Preventiva</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3 Pillars Editorial List */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-3 sm:space-y-3.5">
            
            {/* Pillar 01 */}
            <div className="p-4 sm:p-5 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-[#0071ce]/60 shadow-xs hover:shadow-md transition-all">
              <div className="flex items-center gap-2.5 mb-1.5">
                <span className="text-xs sm:text-sm font-mono font-bold text-[#0071ce] tabular-nums">01</span>
                <span className="text-slate-600">/</span>
                <h3 className="text-sm sm:text-base font-display font-bold text-white">
                  Porque el 86% no lo logra.
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Cerca de 3 millones de venezolanos inician negocios. Solo el 14% logra pasar de negocio a empresa y superar la barrera crítica de los 3.5 años. La diferencia casi nunca está en la idea: radica en la estructura, la formalidad contractual y la anticipación de contingencias.
              </p>
            </div>

            {/* Pillar 02 */}
            <div className="p-4 sm:p-5 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-[#0071ce]/60 shadow-xs hover:shadow-md transition-all">
              <div className="flex items-center gap-2.5 mb-1.5">
                <span className="text-xs sm:text-sm font-mono font-bold text-[#0071ce] tabular-nums">02</span>
                <span className="text-slate-600">/</span>
                <h3 className="text-sm sm:text-base font-display font-bold text-white">
                  Porque las ideas no bastan.
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                <span className="italic font-medium text-white">"No es sobre las ideas. Sino sobre hacer que estas se vuelvan realidad."</span> Creemos firmemente que la ley debe ser una catapulta comercial, no un obstáculo burocrático que frene tus ventas.
              </p>
            </div>

            {/* Pillar 03 */}
            <div className="p-4 sm:p-5 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-[#0071ce]/60 shadow-xs hover:shadow-md transition-all">
              <div className="flex items-center gap-2.5 mb-1.5">
                <span className="text-xs sm:text-sm font-mono font-bold text-[#0071ce] tabular-nums">03</span>
                <span className="text-slate-600">/</span>
                <h3 className="text-sm sm:text-base font-display font-bold text-white">
                  Porque prevenir cuesta menos.
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Anticipar y gestionar los riesgos legales protege tu capital y tu tranquilidad. Un problema evitado mediante una consulta preventiva vale más que diez litigios costosos en tribunales.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
