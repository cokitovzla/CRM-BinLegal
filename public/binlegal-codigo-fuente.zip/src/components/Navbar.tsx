import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Shield, LayoutDashboard, ArrowRight, Menu, X, Users, Sparkles, FolderKanban, LogIn, LogOut, UserCheck, Briefcase, Share2, UserPlus } from 'lucide-react';
import { trackClick, trackNavigation } from '../lib/analytics';

interface NavbarProps {
  currentView: 'landing' | 'admin' | 'ecosystem' | 'portal';
  activeSection?: string;
  onNavigate: (view: 'landing' | 'admin' | 'ecosystem' | 'portal', sectionId?: string) => void;
  unreadLeadsCount?: number;
  onOpenAuth: (mode?: 'login' | 'register' | 'newsletter') => void;
  onOpenShare?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  currentView, 
  onNavigate, 
  unreadLeadsCount = 0,
  onOpenAuth,
  onOpenShare
}) => {
  const { currentUser, userProfile, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const handleNavClick = (sectionId: string) => {
    trackNavigation(sectionId, 'navbar');
    onNavigate('landing', sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 sm:gap-8 h-14 sm:h-16">
          
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={() => onNavigate('landing')}
              className="flex items-center gap-2 sm:gap-2.5 text-left group focus-visible:outline-none"
            >
              <img 
                src="/assets/images/LogoApaisado_BinLegal.png" 
                alt="BinLegal Logo" 
                className="h-7 sm:h-8 md:h-9 w-auto object-contain max-w-[130px] sm:max-w-none" 
              />
              <span className="hidden md:inline-block text-[#3e4543] font-medium text-xs ml-1 pl-2.5 border-l border-slate-300">
                Asesoría Legal · PYME
              </span>
            </button>
          </div>

          {/* Zone 2: 4–5 clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-7 text-xs sm:text-sm font-medium text-neutral-600">
            <button
              onClick={() => handleNavClick('que-hacemos')}
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Qué hacemos
            </button>
            <button
              onClick={() => handleNavClick('por-que')}
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Por qué
            </button>
            <button
              onClick={() => handleNavClick('como')}
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Cómo
            </button>
            <button
              onClick={() => handleNavClick('equipo')}
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Equipo
            </button>
            <button
              onClick={() => handleNavClick('blog')}
              className="hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0"
            >
              Blog
            </button>
            <button
              onClick={() => onNavigate('ecosystem')}
              className={`hover:text-neutral-950 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                currentView === 'ecosystem' ? 'text-neutral-900 font-semibold' : ''
              }`}
            >
              <Users className="w-3.5 h-3.5 text-neutral-500" />
              <span>Ecosistema PYME</span>
            </button>
          </nav>

          {/* Zone 3: Actions, Client Portal & CRM */}
          <div className="hidden sm:flex items-center gap-2.5 shrink-0">
            
            {/* If logged in: Portal Access */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onNavigate('portal')}
                  className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                    currentView === 'portal'
                      ? 'bg-neutral-900 text-white shadow-xs'
                      : 'bg-neutral-100 text-neutral-800 hover:bg-neutral-200 border border-neutral-300'
                  }`}
                  title="Ver mis trámites legales y administrativos"
                >
                  <FolderKanban className="w-3.5 h-3.5" />
                  <span>Mi Portal</span>
                </button>

                {isAdmin && (
                  <button
                    onClick={() => onNavigate(currentView === 'admin' ? 'landing' : 'admin')}
                    className="px-3 py-2 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-lg border border-neutral-300 flex items-center gap-1.5"
                    title="Acceso CRM José Rafael Vásquez"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5 text-neutral-700" />
                    <span>CRM</span>
                    {unreadLeadsCount > 0 && (
                      <span className="text-[10px] font-bold px-1.5 py-0.2 bg-neutral-900 text-white rounded">
                        {unreadLeadsCount}
                      </span>
                    )}
                  </button>
                )}

                <button
                  onClick={logout}
                  className="p-2 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
                  title="Cerrar sesión"
                  aria-label="Cerrar sesión"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              /* If not logged in: Affiliate CTA + Login Button + Free Diagnostic CTA */
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-[#0071ce] hover:bg-[#0060b0] rounded-lg transition-all flex items-center gap-1.5 shadow-2xs whitespace-nowrap active:scale-95 cursor-pointer"
                  title="Crear cuenta gratuita"
                >
                  <UserPlus className="w-3.5 h-3.5 text-white" />
                  <span>Registrarme</span>
                </button>

                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-3 py-2 text-xs font-medium text-[#3e4543] bg-[#f4f5f5] hover:bg-[#e7e8e8] rounded-lg border border-[#cfd1d0] transition-colors flex items-center gap-1.5 whitespace-nowrap"
                  title="Iniciar sesión con correo o usuario"
                >
                  <LogIn className="w-3.5 h-3.5 text-[#4f5553]" />
                  <span>Ingresar</span>
                </button>

                {currentView !== 'admin' && (
                  <button
                    onClick={() => handleNavClick('diagnostico')}
                    className="px-3.5 py-2 text-xs font-medium text-[#3e4543] bg-white hover:bg-[#f4f5f5] rounded-lg border border-[#cfd1d0] transition-all hidden md:flex items-center gap-1.5"
                  >
                    <span>Diagnóstico Gratuito</span>
                  </button>
                )}
              </div>
            )}

            {/* Share button (desktop) */}
            {onOpenShare && (
              <button
                onClick={onOpenShare}
                className="px-2.5 py-2 text-xs font-semibold text-[#3e4543] bg-[#f4f5f5] hover:bg-[#e7e8e8] border border-[#cfd1d0] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs active:scale-95"
                title="Compartir plataforma con amigos y colegas"
              >
                <Share2 className="w-3.5 h-3.5 text-[#0071ce]" />
                <span className="hidden xl:inline">Compartir</span>
              </button>
            )}

            {/* Direct CRM Access button if on landing and not logged in */}
            {!currentUser && currentView === 'landing' && (
              <button
                onClick={() => onNavigate('admin')}
                className="p-2 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                title="Acceso Administrativo / CRM"
                aria-label="CRM"
              >
                <LayoutDashboard className="w-4 h-4" />
              </button>
            )}

          </div>

          {/* Mobile hamburger & share */}
          <div className="flex sm:hidden items-center gap-1.5">
            {onOpenShare && (
              <button
                onClick={onOpenShare}
                className="p-2 text-[#0071ce] bg-blue-50/70 hover:bg-blue-100/70 rounded-lg border border-blue-200"
                title="Compartir enlace"
                aria-label="Compartir"
              >
                <Share2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={currentUser ? () => onNavigate('portal') : () => onOpenAuth()}
              className="p-2 text-neutral-700 bg-neutral-100 rounded-lg border border-neutral-200"
              aria-label="Portal Clientes"
            >
              <FolderKanban className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-neutral-700 hover:text-neutral-950 focus:outline-none"
              aria-label="Abrir menú"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-neutral-200 bg-white px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex flex-col space-y-2 text-sm font-medium text-neutral-700">
            <button
              onClick={() => handleNavClick('que-hacemos')}
              className="text-left py-2 hover:text-neutral-950"
            >
              01 — Qué hacemos
            </button>
            <button
              onClick={() => handleNavClick('por-que')}
              className="text-left py-2 hover:text-neutral-950"
            >
              02 — Por qué lo hacemos
            </button>
            <button
              onClick={() => handleNavClick('como')}
              className="text-left py-2 hover:text-neutral-950"
            >
              03 — Cómo lo hacemos
            </button>
            <button
              onClick={() => handleNavClick('equipo')}
              className="text-left py-2 hover:text-neutral-950"
            >
              04 — Equipo
            </button>
            <button
              onClick={() => handleNavClick('blog')}
              className="text-left py-2 hover:text-neutral-950"
            >
              05 — Blog
            </button>
            <button
              onClick={() => {
                onNavigate('ecosystem');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-neutral-900 font-semibold flex items-center gap-2"
            >
              <Users className="w-4 h-4" />
              <span>Ecosistema & Networking PYME</span>
            </button>
            <button
              onClick={() => handleNavClick('contacto')}
              className="text-left py-2 hover:text-neutral-950"
            >
              07 — Contacto
            </button>
          </div>

          <div className="pt-3 border-t border-neutral-100 flex flex-col gap-2">
            {currentUser ? (
              <>
                <button
                  onClick={() => {
                    onNavigate('portal');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center py-2.5 px-4 bg-neutral-900 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2"
                >
                  <FolderKanban className="w-4 h-4" />
                  <span>Mi Portal de Trámites</span>
                </button>
                {isAdmin && (
                  <button
                    onClick={() => {
                      onNavigate('admin');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-center py-2.5 px-4 bg-neutral-100 text-neutral-800 text-xs font-semibold rounded-lg border border-neutral-300"
                  >
                    CRM José Rafael Vásquez
                  </button>
                )}
                <button
                  onClick={logout}
                  className="w-full text-center py-2 text-neutral-500 text-xs"
                >
                  Cerrar Sesión
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    onOpenAuth('register');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center py-2.5 px-4 bg-[#0071ce] hover:bg-[#0060b0] text-white text-xs font-semibold rounded-lg shadow-xs flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-white" />
                  <span>Registrarme</span>
                </button>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      onOpenAuth('login');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-center py-2 px-3 bg-[#f4f5f5] hover:bg-[#e7e8e8] text-[#3e4543] text-xs font-semibold rounded-lg border border-[#cfd1d0] flex items-center justify-center gap-1.5"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Iniciar Sesión</span>
                  </button>
                  <button
                    onClick={() => {
                      onOpenAuth('newsletter');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-center py-2 px-3 bg-[#f4f5f5] text-[#3e4543] text-xs font-medium rounded-lg border border-[#cfd1d0] flex items-center justify-center gap-1.5"
                  >
                    <span>Boletín</span>
                  </button>
                </div>
                <button
                  onClick={() => handleNavClick('diagnostico')}
                  className="w-full text-center py-2 text-[#0071ce] font-semibold text-xs hover:underline"
                >
                  Diagnóstico Legal Gratuito →
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* FIXED MOBILE BOTTOM TAB BAR (Pattern 1: Navigation Anchor in Thumb Zone) */}
      <nav 
        aria-label="Navegación móvil inferior"
        className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200/90 py-1 px-2 flex items-center justify-around shadow-lg pb-[max(0.5rem,env(safe-area-inset-bottom))]"
      >
        {/* Tab 1: Inicio */}
        <button
          onClick={() => handleNavClick('root')}
          className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 py-1 transition-colors ${
            currentView === 'landing' ? 'text-[#0071ce] font-bold' : 'text-[#626967] hover:text-[#3e4543]'
          }`}
        >
          <Shield className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Inicio</span>
        </button>

        {/* Tab 2: Servicios */}
        <button
          onClick={() => handleNavClick('que-hacemos')}
          className="flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 py-1 text-[#626967] hover:text-[#3e4543] transition-colors"
        >
          <Briefcase className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">Servicios</span>
        </button>

        {/* Tab 3: Diagnóstico (Elevated Primary Thumb Action) */}
        <button
          onClick={() => handleNavClick('diagnostico')}
          className="flex flex-col items-center justify-center min-w-[60px] min-h-[48px] px-2.5 py-1 text-[#3e4543] transition-transform active:scale-95"
        >
          <div className="w-9 h-9 -mt-3.5 bg-[#0071ce] text-white rounded-full flex items-center justify-center shadow-md">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-bold tracking-tight text-[#0071ce] mt-0.5">Diagnóstico</span>
        </button>

        {/* Tab 4: Mi Portal (if logged in) or Afiliarme (if not logged in) */}
        {currentUser ? (
          <button
            onClick={() => onNavigate('portal')}
            className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 py-1 transition-colors ${
              currentView === 'portal' ? 'text-neutral-950 font-bold' : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <FolderKanban className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Mi Portal</span>
          </button>
        ) : (
          <button
            onClick={() => onOpenAuth('register')}
            className="flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-1.5 py-1 text-neutral-900 font-bold relative active:scale-95 transition-transform"
            title="Afiliarme gratis y recibir el boletín legal"
          >
            <div className="relative">
              <UserCheck className="w-5 h-5 mb-0.5 text-neutral-950" />
              <span className="absolute -top-1 -right-2.5 px-1 py-0.2 bg-amber-400 text-neutral-950 text-[7px] font-extrabold rounded-full leading-none shadow-xs">
                Gratis
              </span>
            </div>
            <span className="text-[10px] tracking-tight">Afiliarme</span>
          </button>
        )}

        {/* Tab 5: CRM / Ecosistema */}
        {isAdmin ? (
          <button
            onClick={() => onNavigate(currentView === 'admin' ? 'landing' : 'admin')}
            className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 py-1 transition-colors ${
              currentView === 'admin' ? 'text-neutral-950 font-bold' : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <LayoutDashboard className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">CRM</span>
          </button>
        ) : (
          <button
            onClick={() => onNavigate('ecosystem')}
            className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 py-1 transition-colors ${
              currentView === 'ecosystem' ? 'text-neutral-950 font-bold' : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            <Users className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] tracking-tight">Ecosistema</span>
          </button>
        )}
      </nav>
    </header>
  );
};
