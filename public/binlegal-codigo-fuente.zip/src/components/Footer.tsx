import React from 'react';
import { Lock } from 'lucide-react';
import { trackNavigation, trackClick } from '../lib/analytics';

interface FooterProps {
  onNavigateSection: (sectionId: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateSection, onOpenAdmin }) => {
  const handleFooterNav = (sectionId: string) => {
    trackNavigation(sectionId, 'footer');
    onNavigateSection(sectionId);
  };
  return (
    <footer className="bg-white border-t border-neutral-200 pt-8 sm:pt-10 pb-20 sm:pb-8 text-xs text-neutral-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 pb-6 sm:pb-8 border-b border-neutral-200/80">
          
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <img 
                src="/assets/images/LogoApaisado_BinLegal.png" 
                alt="BinLegal Logo" 
                className="h-7 sm:h-8 w-auto object-contain" 
              />
            </div>
            
            <p className="text-xs text-slate-600 leading-relaxed max-w-sm">
              Asesoría legal estratégica para PYME. Impulsamos y protegemos tu negocio en cada etapa de su crecimiento con soluciones directas y ágiles.
            </p>

            <div className="text-[11px] text-neutral-400 font-mono">
              Fundado por José Rafael Vásquez · Caracas, Venezuela
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3 space-y-2">
            <div className="text-[11px] font-semibold text-neutral-900 uppercase tracking-wider">
              Navegación
            </div>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => handleFooterNav('que-hacemos')}
                  data-track-section="footer"
                  data-track-name="footer_que_hacemos"
                  className="hover:text-neutral-950 transition-colors cursor-pointer"
                >
                  01 — Qué hacemos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleFooterNav('por-que')}
                  data-track-section="footer"
                  data-track-name="footer_por_que"
                  className="hover:text-neutral-950 transition-colors cursor-pointer"
                >
                  02 — Por qué lo hacemos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleFooterNav('como')}
                  data-track-section="footer"
                  data-track-name="footer_como"
                  className="hover:text-neutral-950 transition-colors cursor-pointer"
                >
                  03 — Cómo lo hacemos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleFooterNav('equipo')}
                  data-track-section="footer"
                  data-track-name="footer_equipo"
                  className="hover:text-neutral-950 transition-colors cursor-pointer"
                >
                  04 — Equipo
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleFooterNav('blog')}
                  data-track-section="footer"
                  data-track-name="footer_blog"
                  className="hover:text-neutral-950 transition-colors cursor-pointer"
                >
                  05 — Blog
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleFooterNav('diagnostico')}
                  data-track-section="footer"
                  data-track-name="footer_diagnostico"
                  className="hover:text-[#0071ce] font-semibold text-[#0071ce] transition-colors cursor-pointer"
                >
                  06 — Diagnóstico Gratuito
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div className="md:col-span-4 space-y-2">
            <div className="text-[11px] font-semibold text-neutral-900 uppercase tracking-wider">
              Contacto Directo
            </div>
            <div className="space-y-1 text-xs text-neutral-600">
              <div>
                <a href="mailto:contacto@binlegal.com" className="hover:text-neutral-950 transition-colors font-medium">
                  contacto@binlegal.com
                </a>
              </div>
              <div className="font-mono text-[11px]">
                +58 212 900 2460 / +58 412 246 8800
              </div>
              <div className="text-neutral-500">
                Torre Xerox, Piso 9, Av. Francisco de Miranda, Chacao, Caracas.
              </div>
            </div>

            <div className="pt-1.5">
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-md text-xs font-medium border border-neutral-200 transition-colors cursor-pointer"
              >
                <Lock className="w-3 h-3" />
                <span>Panel Admin / CRM</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-4 sm:pt-6 flex flex-col sm:flex-row items-center justify-between gap-2.5 text-[11px] text-neutral-500">
          <div>
            © 2026 BinLegal. Soluciones legales alternativas. Todos los derechos reservados.
          </div>
          <div className="flex items-center gap-3">
            <span>Aviso Legal</span>
            <span aria-hidden="true">·</span>
            <span>Términos y Condiciones</span>
            <span aria-hidden="true">·</span>
            <span>Privacidad de Datos</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
