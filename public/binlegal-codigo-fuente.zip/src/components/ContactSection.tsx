import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Mail, Phone, MapPin, Send, CheckCircle2, MessageCircle } from 'lucide-react';
import { trackClick, trackWhatsAppClick, trackAuthAction } from '../lib/analytics';

interface ContactSectionProps {
  onOpenAdmin: () => void;
  onOpenAuth?: (mode?: 'login' | 'register' | 'newsletter') => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenAdmin, onOpenAuth }) => {
  const { subscribeNewsletter } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [newsletterLoading, setNewsletterLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;
    trackClick('contacto', 'enviar_mensaje_directo', {
      has_company: Boolean(company.trim()),
    });
    setSubmitted(true);
    setName('');
    setEmail('');
    setCompany('');
    setMessage('');
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) return;
    setNewsletterLoading(true);
    try {
      trackAuthAction('newsletter_subscribe', { source: 'contacto_footer' });
      await subscribeNewsletter(newsletterEmail);
      setNewsletterSubscribed(true);
      setNewsletterEmail('');
    } catch (e) {
      console.error(e);
    } finally {
      setNewsletterLoading(false);
    }
  };

  return (
    <section id="contacto" className="py-10 sm:py-12 lg:py-14 bg-slate-50/70 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-6 sm:mb-8">
          <div className="text-[11px] sm:text-xs font-semibold tracking-wider text-[#0071ce] uppercase mb-1.5 sm:mb-2">
            07 — Contacto
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold text-slate-950 tracking-tight mb-2 text-balance">
            Hablemos de tu negocio.
          </h2>
          <p className="text-xs sm:text-sm lg:text-base text-slate-600 leading-relaxed">
            ¿Tienes un reto legal o simplemente quieres estar preparado? Escríbenos y coordinamos una primera conversación directa y sin vueltas con nuestro equipo.
          </p>
        </div>

        {/* 2-Column Contact & Channels */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 mb-8 sm:mb-10">
          
          {/* Direct Message Form */}
          <div className="lg:col-span-7 bg-white p-4 sm:p-6 lg:p-7 rounded-xl border border-slate-200/90 shadow-xs">
            {submitted ? (
              <div className="text-center py-8 space-y-2.5 animate-in fade-in">
                <div className="w-10 h-10 bg-neutral-900 text-white rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                </div>
                <h3 className="text-lg font-display font-bold text-neutral-950">
                  Mensaje recibido correctamente
                </h3>
                <p className="text-xs text-neutral-600 max-w-md mx-auto">
                  José Rafael Vásquez o uno de los abogados socios revisará tus requerimientos y te responderá en menos de 24 horas laborables.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-3 px-4 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors cursor-pointer"
                >
                  Enviar otro mensaje
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Nombre *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Tu nombre y apellido"
                      className="w-full px-3 py-2 bg-neutral-50/50 border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Correo *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="nombre@empresa.com"
                      className="w-full px-3 py-2 bg-neutral-50/50 border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Empresa (opcional)
                  </label>
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Nombre comercial o proyecto"
                    className="w-full px-3 py-2 bg-neutral-50/50 border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    ¿En qué podemos ayudarte? *
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe tu situación, consulta o inquietud legal..."
                    className="w-full px-3 py-2 bg-neutral-50/50 border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-900"
                  />
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-5 py-2.5 bg-[#0071ce] hover:bg-[#0060b0] text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-95"
                  >
                    <span>Enviar mensaje</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Contact Details & Channels */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="bg-white p-4 sm:p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
              <h3 className="text-base sm:text-lg font-display font-bold text-neutral-950">
                Canales de Atención Directa
              </h3>

              <div className="space-y-3.5 text-xs sm:text-sm text-neutral-700">
                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-neutral-100 flex items-center justify-center shrink-0">
                    <Mail className="w-3.5 h-3.5 text-neutral-900" />
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider">
                      Correo Electrónico
                    </div>
                    <a 
                      href="mailto:contacto@binlegal.com" 
                      onClick={() => trackClick('contacto', 'click_email')}
                      data-track-section="contacto"
                      data-track-name="email_contacto"
                      className="font-semibold text-neutral-900 hover:underline"
                    >
                      contacto@binlegal.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-neutral-100 flex items-center justify-center shrink-0">
                    <Phone className="w-3.5 h-3.5 text-neutral-900" />
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider">
                      Teléfono / WhatsApp de Guardia
                    </div>
                    <a
                      href="https://wa.me/584122468800"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => trackWhatsAppClick('contacto_directo')}
                      data-track-section="contacto"
                      data-track-name="whatsapp_contacto_directo"
                      className="font-semibold text-neutral-900 font-mono text-xs hover:text-[#0071ce] flex items-center gap-1.5 transition-colors"
                    >
                      <span>+58 212 900 2460 / +58 412 246 8800</span>
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-neutral-100 flex items-center justify-center shrink-0">
                    <MapPin className="w-3.5 h-3.5 text-neutral-900" />
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider">
                      Ubicación Principal
                    </div>
                    <div className="text-neutral-700 text-xs">
                      Caracas, Venezuela · Atención remota a nivel nacional y PYMES regionales en LATAM.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick response commitment */}
            <div className="p-4 rounded-xl bg-neutral-900 text-white">
              <div className="text-[10px] font-mono uppercase text-neutral-400 mb-0.5">
                Compromiso BinLegal
              </div>
              <h4 className="text-sm font-bold mb-1">
                Cero burocracia, respuestas en menos de 24 horas.
              </h4>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Sabemos que los negocios no pueden esperar semanas por una opinión legal. Nuestro modelo prioriza la agilidad y la claridad ejecutiva.
              </p>
            </div>
          </div>

        </div>

        {/* Newsletter Section - Synthesized */}
        <div className="bg-white p-4 sm:p-6 lg:p-7 rounded-xl border border-neutral-200 flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6 shadow-2xs">
          <div className="max-w-md">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-neutral-400 mb-0.5">
              Newsletter
            </div>
            <h3 className="text-base sm:text-lg font-display font-bold text-neutral-950 mb-1">
              Inteligencia legal para tu negocio, cada mes.
            </h3>
            <p className="text-xs text-neutral-600">
              Casos reales, cambios de normativas, modelos descargables y consejos directos sin spam.
            </p>
          </div>

          <div className="w-full md:w-auto">
            {newsletterSubscribed ? (
              <div className="flex items-center gap-2 text-xs font-semibold text-neutral-900 bg-neutral-100 px-3.5 py-2.5 rounded-lg">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>¡Suscripción confirmada! Te enviaremos la próxima edición.</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-2 w-full max-w-md">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="nombre@empresa.com"
                  className="px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs text-neutral-900 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-900 min-w-[200px]"
                />
                <button
                  type="submit"
                  disabled={newsletterLoading}
                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white font-semibold text-xs rounded-lg transition-colors whitespace-nowrap shadow-xs cursor-pointer active:scale-95"
                >
                  {newsletterLoading ? 'Enviando...' : 'Suscribirme'}
                </button>
              </form>
            )}
          </div>
        </div>

      </div>
    </section>
  );
};
