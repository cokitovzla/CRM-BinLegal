import React, { useState } from 'react';
import { Lead, LeadStatus, BusinessStage, LegalArea, InternalNote, LegalProcess, ProcessStatus } from '../types';
import { 
  Users, 
  Search, 
  Filter, 
  ArrowRight, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  MessageSquare, 
  Plus, 
  Download, 
  X, 
  Phone, 
  Mail, 
  Building, 
  AlertTriangle, 
  ChevronRight, 
  Send, 
  Briefcase,
  Layers,
  LayoutGrid,
  List,
  FolderKanban
} from 'lucide-react';
import { SectorSelector, COMMON_BUSINESS_SECTORS } from './SectorSelector';

interface AdminCRMProps {
  leads: Lead[];
  processes?: LegalProcess[];
  onUpdateLeadStatus: (leadId: string, newStatus: LeadStatus) => void;
  onAddInternalNote: (leadId: string, noteText: string, author: string) => void;
  onAddManualLead: (lead: Lead) => void;
  onUpdateProcessStatus?: (processId: string, status: ProcessStatus, progress: number, milestone?: string) => void;
  onBackToLanding: () => void;
}

const STAGES_CONFIG: Array<{ id: LeadStatus; label: string; desc: string }> = [
  { id: 'nuevo_lead', label: 'Nuevo Lead', desc: 'Diagnóstico recién recibido' },
  { id: 'diagnostico_enviado', label: 'Diagnóstico Enviado', desc: 'Mapa enviado por correo' },
  { id: 'sesion_programada', label: 'Sesión Programada', desc: 'Llamada de 25 min agendada' },
  { id: 'propuesta_presentada', label: 'Propuesta Presentada', desc: 'Cotización por fases enviada' },
  { id: 'cliente_activo', label: 'Cliente Activo', desc: 'Contrato firmado / En ejecución' }
];

export const AdminCRM: React.FC<AdminCRMProps> = ({
  leads,
  processes = [],
  onUpdateLeadStatus,
  onAddInternalNote,
  onAddManualLead,
  onUpdateProcessStatus,
  onBackToLanding
}) => {
  const [adminTab, setAdminTab] = useState<'leads' | 'processes'>('leads');
  const [activeView, setActiveView] = useState<'pipeline' | 'table'>('pipeline');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStageFilter, setSelectedStageFilter] = useState<string>('all');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<string>('all');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [selectedProcessToEdit, setSelectedProcessToEdit] = useState<LegalProcess | null>(null);

  // New Note state
  const [noteText, setNoteText] = useState('');
  const [noteAuthor, setNoteAuthor] = useState('José Rafael Vásquez');

  // Manual Lead Modal state
  const [showAddLeadModal, setShowAddLeadModal] = useState(false);
  const [newFullName, setNewFullName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newSelectedSectors, setNewSelectedSectors] = useState<string[]>(['Tecnología & Software']);
  const [newOtherSectorText, setNewOtherSectorText] = useState('');
  const [newStage, setNewStage] = useState<BusinessStage>('Recién constituida');
  const [newAreas, setNewAreas] = useState<LegalArea[]>(['Corporativo']);
  const [newSituation, setNewSituation] = useState('');

  // Filter leads
  const filteredLeads = leads.filter(l => {
    const matchesSearch = l.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          l.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          l.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          l.industry.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = selectedStageFilter === 'all' || l.status === selectedStageFilter;
    const matchesSector = selectedSectorFilter === 'all' || 
                          l.industry.toLowerCase().includes(selectedSectorFilter.toLowerCase());
    return matchesSearch && matchesStage && matchesSector;
  });

  // KPI Calculations
  const totalLeads = leads.length;
  const activeClients = leads.filter(l => l.status === 'cliente_activo').length;
  const inPipeline = leads.filter(l => l.status !== 'cliente_activo').length;
  const sessionsScheduled = leads.filter(l => l.status === 'sesion_programada').length;
  const conversionRate = totalLeads > 0 ? Math.round((activeClients / totalLeads) * 100) : 0;

  const handleAddNote = (leadId: string) => {
    if (!noteText.trim()) return;
    onAddInternalNote(leadId, noteText, noteAuthor);
    setNoteText('');
    
    // Update local selectedLead state
    if (selectedLead && selectedLead.id === leadId) {
      const updatedNotes: InternalNote[] = [
        ...selectedLead.internalNotes,
        {
          id: `note-${Date.now()}`,
          author: noteAuthor,
          text: noteText,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
        }
      ];
      setSelectedLead({ ...selectedLead, internalNotes: updatedNotes });
    }
  };

  const handleStatusChange = (leadId: string, newStatus: LeadStatus) => {
    onUpdateLeadStatus(leadId, newStatus);
    if (selectedLead && selectedLead.id === leadId) {
      setSelectedLead({ ...selectedLead, status: newStatus });
    }
  };

  const handleSaveManualLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFullName || !newEmail || !newCompany) return;

    const formattedIndustry = newSelectedSectors.map(s => {
      if (s === 'Otro') {
        return newOtherSectorText.trim() ? `Otro: ${newOtherSectorText.trim()}` : 'Otro';
      }
      return s;
    }).join(', ') || 'PYME General';

    const lead: Lead = {
      id: `lead-manual-${Date.now()}`,
      fullName: newFullName,
      email: newEmail,
      phone: newPhone || undefined,
      company: newCompany,
      industry: formattedIndustry,
      stage: newStage,
      areasOfInterest: newAreas,
      notes: newSituation || undefined,
      status: 'nuevo_lead',
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      calculatedRiskScore: 60,
      riskSummary: `Registrado manualmente por ${noteAuthor} para prospección directa.`,
      riskItems: [
        {
          area: newAreas[0] || 'Corporativo',
          level: 'Medio',
          title: 'Evaluación inicial pendiente',
          description: 'Contacto directo de ventas para diagnóstico telefónico o presencial.',
          actionRequired: 'Agendar llamada de calificación de 15 minutos.'
        }
      ],
      internalNotes: [
        {
          id: `note-${Date.now()}`,
          author: noteAuthor,
          text: 'Prospecto creado manualmente en el CRM.',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
        }
      ]
    };

    onAddManualLead(lead);
    setShowAddLeadModal(false);
    setNewFullName('');
    setNewEmail('');
    setNewPhone('');
    setNewCompany('');
    setNewSelectedSectors(['Tecnología & Software']);
    setNewOtherSectorText('');
  };

  const exportCSV = () => {
    const headers = ['ID', 'Nombre', 'Empresa', 'Email', 'Telefono', 'Etapa', 'Areas', 'Estado', 'Riesgo', 'Fecha'];
    const rows = leads.map(l => [
      l.id,
      `"${l.fullName}"`,
      `"${l.company}"`,
      l.email,
      l.phone || '',
      `"${l.stage}"`,
      `"${l.areasOfInterest.join(';')}"`,
      l.status,
      l.calculatedRiskScore,
      l.createdAt
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `binlegal_leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col font-sans">
      
      {/* Top Bar for Admin */}
      <header className="bg-neutral-900 text-white border-b border-neutral-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between min-h-[56px] py-2 sm:h-14 gap-2.5">
            
            <div className="flex items-center gap-2.5">
              <img 
                src="/assets/images/LogoApaisado_BinLegal.png" 
                alt="BinLegal Logo" 
                className="h-7 sm:h-8 w-auto object-contain bg-white rounded p-1" 
              />
              <div>
                <h1 className="text-xs sm:text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                  <span>BinLegal CRM</span>
                  <span className="text-neutral-500 font-normal">|</span>
                  <span className="text-[11px] text-neutral-300 font-normal hidden sm:inline">
                    José Rafael Vásquez
                  </span>
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Tab Selector in CRM */}
              <div className="flex items-center gap-1 p-0.5 bg-neutral-800 rounded-lg border border-neutral-700">
                <button
                  onClick={() => setAdminTab('leads')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                    adminTab === 'leads' ? 'bg-white text-neutral-900 shadow-2xs' : 'text-neutral-300 hover:text-white'
                  }`}
                >
                  Prospectos ({leads.length})
                </button>
                <button
                  onClick={() => setAdminTab('processes')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all flex items-center gap-1 cursor-pointer ${
                    adminTab === 'processes' ? 'bg-white text-neutral-900 shadow-2xs' : 'text-neutral-300 hover:text-white'
                  }`}
                >
                  <FolderKanban className="w-3.5 h-3.5" />
                  <span>Expedientes ({processes.length})</span>
                </button>
              </div>

              {adminTab === 'leads' && (
                <>
                  <button
                    onClick={() => setShowAddLeadModal(true)}
                    className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors flex items-center gap-1 border border-neutral-700 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Nuevo Lead</span>
                  </button>

                  <button
                    onClick={exportCSV}
                    className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs font-medium transition-colors flex items-center gap-1 border border-neutral-700 cursor-pointer"
                    title="Exportar base a CSV"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">CSV</span>
                  </button>
                </>
              )}

              <button
                onClick={onBackToLanding}
                className="px-3 py-1 bg-white text-neutral-900 rounded text-xs font-semibold hover:bg-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>Ver Web</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Main CRM Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4">
        
        {/* Render Leads view when adminTab === 'leads' */}
        {adminTab === 'leads' ? (
          <>
            {/* KPI Metric Strip (Tabular Numerals) */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Total Prospectos
                </div>
                <div className="text-2xl font-display font-extrabold text-slate-950 mt-1 tabular-nums">
                  {totalLeads}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Registrados en total
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  En Pipeline Activo
                </div>
                <div className="text-2xl font-display font-extrabold text-[#0071ce] mt-1 tabular-nums">
                  {inPipeline}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  En negociación
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Sesiones Agendadas
                </div>
                <div className="text-2xl font-display font-extrabold text-slate-950 mt-1 tabular-nums">
                  {sessionsScheduled}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Videollamadas 1-on-1
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Clientes Activos
                </div>
                <div className="text-2xl font-display font-extrabold text-emerald-600 mt-1 tabular-nums">
                  {activeClients}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Contratos en vigor
                </div>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md col-span-2 sm:col-span-1">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Tasa de Cierre
                </div>
                <div className="text-2xl font-display font-extrabold text-slate-950 mt-1 tabular-nums">
                  {conversionRate}%
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Efectividad comercial
                </div>
              </div>
            </div>

        {/* Filter and View Mode Switcher */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-md flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          <div className="flex flex-1 items-center gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por prospecto, empresa, correo o sector..."
                className="w-full pl-9 pr-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-lg text-xs text-neutral-900 focus:outline-none focus:bg-white"
              />
            </div>

            <div className="hidden sm:flex items-center gap-2">
              <span className="text-xs text-neutral-500">Etapa:</span>
              <select
                value={selectedStageFilter}
                onChange={(e) => setSelectedStageFilter(e.target.value)}
                className="bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs text-neutral-800 focus:outline-none"
              >
                <option value="all">Todas las etapas</option>
                {STAGES_CONFIG.map(st => (
                  <option key={st.id} value={st.id}>{st.label}</option>
                ))}
              </select>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <span className="text-xs text-neutral-500">Sector:</span>
              <select
                value={selectedSectorFilter}
                onChange={(e) => setSelectedSectorFilter(e.target.value)}
                className="bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs text-neutral-800 focus:outline-none max-w-[160px] truncate"
              >
                <option value="all">Todos los sectores</option>
                {COMMON_BUSINESS_SECTORS.map(sec => {
                  const val = sec.id === 'otro' ? 'Otro' : sec.name;
                  return (
                    <option key={sec.id} value={val}>{sec.name}</option>
                  );
                })}
              </select>
            </div>
          </div>

          {/* View switcher */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg shrink-0 border border-neutral-200 self-end md:self-auto">
            <button
              onClick={() => setActiveView('pipeline')}
              className={`px-3 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-colors ${
                activeView === 'pipeline'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Embudo (Kanban)</span>
            </button>
            <button
              onClick={() => setActiveView('table')}
              className={`px-3 py-1 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-colors ${
                activeView === 'table'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Lista / Bandeja</span>
            </button>
          </div>

        </div>

        {/* VIEW 1: PIPELINE / KANBAN */}
        {activeView === 'pipeline' && (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 overflow-x-auto pb-6">
            {STAGES_CONFIG.map((stage) => {
              const stageLeads = filteredLeads.filter(l => l.status === stage.id);
              return (
                <div 
                  key={stage.id} 
                  className="bg-neutral-50/80 rounded-xl border border-neutral-200 p-3 flex flex-col min-w-[240px] max-w-full"
                >
                  {/* Column Header */}
                  <div className="pb-3 mb-3 border-b border-neutral-200/90 flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-neutral-900">
                        {stage.label}
                      </h3>
                      <p className="text-[10px] text-neutral-400 font-normal">
                        {stage.desc}
                      </p>
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 bg-neutral-200 rounded-full text-neutral-800 tabular-nums">
                      {stageLeads.length}
                    </span>
                  </div>

                  {/* Cards inside stage */}
                  <div className="space-y-3 flex-1 overflow-y-auto max-h-[70vh]">
                    {stageLeads.map((lead) => (
                      <div
                        key={lead.id}
                        onClick={() => setSelectedLead(lead)}
                        className="bg-white p-4 rounded-xl border border-slate-200/90 hover:border-[#0071ce]/50 shadow-md hover:shadow-lg transition-all cursor-pointer space-y-2 group"
                      >
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="text-xs font-bold text-neutral-950 group-hover:text-neutral-800 transition-colors line-clamp-1">
                            {lead.company}
                          </h4>
                          <span className="text-[10px] font-mono text-neutral-400 shrink-0">
                            {lead.calculatedRiskScore}/100
                          </span>
                        </div>

                        <div className="text-[11px] text-neutral-600 font-medium truncate">
                          {lead.fullName}
                        </div>

                        <div className="text-[10px] text-neutral-400 truncate font-mono">
                          {lead.stage} · {lead.industry}
                        </div>

                        {/* Areas tags */}
                        <div className="flex flex-wrap gap-1 pt-1">
                          {lead.areasOfInterest.slice(0, 2).map((area, i) => (
                            <span key={i} className="text-[9px] bg-neutral-100 text-neutral-600 px-1.5 py-0.5 rounded">
                              {area}
                            </span>
                          ))}
                          {lead.areasOfInterest.length > 2 && (
                            <span className="text-[9px] text-neutral-400">
                              +{lead.areasOfInterest.length - 2}
                            </span>
                          )}
                        </div>

                        {/* Bottom card info */}
                        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-[10px] text-neutral-400 font-mono">
                          <span>{lead.createdAt.slice(5, 10)}</span>
                          <span className="flex items-center gap-1 text-neutral-600 font-sans">
                            <MessageSquare className="w-2.5 h-2.5" />
                            <span>{lead.internalNotes.length}</span>
                          </span>
                        </div>
                      </div>
                    ))}

                    {stageLeads.length === 0 && (
                      <div className="p-4 text-center text-xs text-neutral-400 italic">
                        Sin prospectos en esta etapa
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 2: HIGH-DENSITY TABLE */}
        {activeView === 'table' && (
          <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
                    <th className="py-3 px-4">Empresa / Contacto</th>
                    <th className="py-3 px-4">Etapa del Negocio</th>
                    <th className="py-3 px-4">Áreas Marcadas</th>
                    <th className="py-3 px-4">Riesgo Calculado</th>
                    <th className="py-3 px-4">Estado en Pipeline</th>
                    <th className="py-3 px-4">Fecha</th>
                    <th className="py-3 px-4 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 text-neutral-700">
                  {filteredLeads.map((lead) => (
                    <tr 
                      key={lead.id} 
                      onClick={() => setSelectedLead(lead)}
                      className="hover:bg-neutral-50/70 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-neutral-950">{lead.company}</div>
                        <div className="text-[11px] text-neutral-500">{lead.fullName} · {lead.email}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px]">
                        {lead.stage}
                        <div className="text-neutral-400 text-[10px] font-sans">{lead.industry}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1">
                          {lead.areasOfInterest.map((a, i) => (
                            <span key={i} className="text-[10px] bg-neutral-100 text-neutral-700 px-1.5 py-0.5 rounded">
                              {a}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums font-semibold">
                        <span className={lead.calculatedRiskScore >= 70 ? 'text-red-700' : 'text-neutral-800'}>
                          {lead.calculatedRiskScore} / 100
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[11px] font-medium text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded">
                          {STAGES_CONFIG.find(s => s.id === lead.status)?.label}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-400 text-[11px]">
                        {lead.createdAt}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedLead(lead);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-neutral-900 hover:bg-neutral-100 rounded border border-neutral-200"
                        >
                          Ver Detalle
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
          </>
        ) : (
          /* PROCESSES TAB FOR ADMIN */
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="bg-white p-4 rounded-xl border border-neutral-200">
                <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">Total Expedientes</div>
                <div className="text-2xl font-display font-extrabold text-neutral-950 mt-1 tabular-nums">{processes.length}</div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-neutral-200">
                <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">En Redacción</div>
                <div className="text-2xl font-display font-extrabold text-neutral-950 mt-1 tabular-nums">
                  {processes.filter(p => p.status === 'redaccion').length}
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-neutral-200">
                <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">En Ente Público</div>
                <div className="text-2xl font-display font-extrabold text-neutral-950 mt-1 tabular-nums">
                  {processes.filter(p => p.status === 'tramite_publico').length}
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-neutral-200">
                <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">En Revisión</div>
                <div className="text-2xl font-display font-extrabold text-neutral-950 mt-1 tabular-nums">
                  {processes.filter(p => p.status === 'revision').length}
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-neutral-200 col-span-2 sm:col-span-1">
                <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">Finalizados</div>
                <div className="text-2xl font-display font-extrabold text-neutral-950 mt-1 tabular-nums">
                  {processes.filter(p => p.status === 'completado').length}
                </div>
              </div>
            </div>

            {/* Processes List Table for Admin */}
            <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs">
              <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-950">Expedientes Legales y Administrativos Activos</h3>
                  <p className="text-xs text-neutral-500">Actualiza el avance de los trámites para que el cliente lo vea en su portal en tiempo real.</p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
                      <th className="py-3 px-4">Trámite / Cliente</th>
                      <th className="py-3 px-4">Categoría</th>
                      <th className="py-3 px-4">Abogado Líder</th>
                      <th className="py-3 px-4">Fase Actual</th>
                      <th className="py-3 px-4">Avance</th>
                      <th className="py-3 px-4">Próximo Hito</th>
                      <th className="py-3 px-4 text-right">Actualizar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200 text-neutral-700">
                    {processes.map((proc) => (
                      <tr key={proc.id} className="hover:bg-neutral-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-bold text-neutral-950">{proc.title}</div>
                          <div className="text-[11px] text-neutral-500">{proc.clientName} ({proc.companyName || proc.clientEmail})</div>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px]">{proc.category}</td>
                        <td className="py-3 px-4 font-semibold text-neutral-900">{proc.assignedLawyer}</td>
                        <td className="py-3 px-4">
                          <span className="text-[11px] font-medium text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded uppercase font-mono">
                            {proc.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold tabular-nums">
                          {proc.progress}%
                        </td>
                        <td className="py-3 px-4 max-w-xs truncate text-neutral-600">
                          {proc.nextMilestone}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setSelectedProcessToEdit(proc)}
                            className="px-2.5 py-1 text-xs font-semibold text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded border border-neutral-300"
                          >
                            Modificar
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* LEAD DOSSIER MODAL / DRAWER */}
      {selectedLead && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white w-full max-w-3xl rounded-2xl border border-neutral-200 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            
            {/* Dossier Header */}
            <div className="p-6 border-b border-neutral-200 flex items-start justify-between bg-neutral-50">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-500 mb-1">
                  <span>Lead ID: {selectedLead.id}</span>
                  <span>·</span>
                  <span>Ingreso: {selectedLead.createdAt}</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-display font-extrabold text-neutral-950">
                  {selectedLead.company}
                </h3>
                <div className="text-xs text-neutral-600 mt-0.5">
                  Contacto: <strong className="text-neutral-900">{selectedLead.fullName}</strong> ({selectedLead.industry})
                </div>
              </div>

              <button
                onClick={() => setSelectedLead(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dossier Body */}
            <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm">
              
              {/* Pipeline Quick Transition Control */}
              <div className="p-4 bg-neutral-900 text-white rounded-xl space-y-2">
                <div className="text-xs uppercase tracking-wider text-neutral-400 font-mono">
                  Etapa actual en el embudo comercial:
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {STAGES_CONFIG.map(st => (
                    <button
                      key={st.id}
                      onClick={() => handleStatusChange(selectedLead.id, st.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        selectedLead.status === st.id
                          ? 'bg-white text-neutral-900 shadow-xs'
                          : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Contact info cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <span className="text-[10px] text-neutral-400 uppercase font-semibold">Correo de Contacto</span>
                  <div className="font-semibold text-neutral-900 truncate mt-0.5">
                    <a href={`mailto:${selectedLead.email}`} className="hover:underline flex items-center gap-1">
                      <Mail className="w-3 h-3 text-neutral-500 shrink-0" />
                      <span className="truncate">{selectedLead.email}</span>
                    </a>
                  </div>
                </div>

                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <span className="text-[10px] text-neutral-400 uppercase font-semibold">Teléfono / WhatsApp</span>
                  <div className="font-semibold text-neutral-900 mt-0.5">
                    {selectedLead.phone ? (
                      <a href={`https://wa.me/${selectedLead.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                        <Phone className="w-3 h-3 text-neutral-500 shrink-0" />
                        <span>{selectedLead.phone}</span>
                      </a>
                    ) : (
                      <span className="text-neutral-400 italic">No suministrado</span>
                    )}
                  </div>
                </div>

                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <span className="text-[10px] text-neutral-400 uppercase font-semibold">Etapa de la Empresa</span>
                  <div className="font-semibold text-neutral-900 mt-0.5">
                    {selectedLead.stage}
                  </div>
                </div>
              </div>

              {/* Segmented Industry Tags */}
              <div>
                <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Sector / Industria Segmentada</span>
                  <span className="text-[10px] text-neutral-400 font-mono">
                    {selectedLead.industry.includes(',') ? `${selectedLead.industry.split(',').length} sectores` : '1 sector'}
                  </span>
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedLead.industry.split(',').map((ind, i) => (
                    <span 
                      key={i} 
                      className="px-2.5 py-1 bg-neutral-900 text-white rounded-lg text-xs font-semibold tracking-tight shadow-2xs"
                    >
                      {ind.trim()}
                    </span>
                  ))}
                </div>
              </div>

              {/* Areas of Interest */}
              <div>
                <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2">
                  Áreas de Interés Consultadas
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedLead.areasOfInterest.map((area, i) => (
                    <span key={i} className="px-3 py-1 bg-neutral-100 text-neutral-800 rounded-lg text-xs font-medium border border-neutral-200">
                      {area}
                    </span>
                  ))}
                </div>
              </div>

              {/* Customer Situation Note if given */}
              {selectedLead.notes && (
                <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-1">
                  <h4 className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Situación descrita por el prospecto:
                  </h4>
                  <p className="text-neutral-700 italic">
                    "{selectedLead.notes}"
                  </p>
                </div>
              )}

              {/* Risk Diagnostic Summary */}
              <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-neutral-900 uppercase tracking-wider">
                    Evaluación de Riesgo Automática
                  </h4>
                  <span className="text-xs font-mono font-bold text-neutral-900">
                    Puntaje: {selectedLead.calculatedRiskScore}/100
                  </span>
                </div>
                <p className="text-xs text-neutral-600">
                  {selectedLead.riskSummary}
                </p>

                {/* Risk Items */}
                <div className="space-y-2 pt-2">
                  {selectedLead.riskItems.map((item, idx) => (
                    <div key={idx} className="bg-white p-3 rounded-lg border border-neutral-200 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-neutral-900">{item.title}</span>
                        <span className="text-[10px] font-bold text-neutral-500 font-mono">
                          {item.area} · Riesgo {item.level}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-600">
                        {item.description}
                      </p>
                      <div className="text-[11px] text-neutral-900 font-medium pt-1">
                        Acción: {item.actionRequired}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Internal Follow-up Notes Timeline (Core requirement for José Rafael) */}
              <div className="space-y-3 pt-4 border-t border-neutral-200">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-neutral-950 uppercase tracking-wider">
                    Bitácora de Notas Internas de Seguimiento ({selectedLead.internalNotes.length})
                  </h4>
                  <span className="text-[11px] text-neutral-400">
                    Solo visible para el equipo legal
                  </span>
                </div>

                {/* Note list */}
                <div className="space-y-2">
                  {selectedLead.internalNotes.map((note) => (
                    <div key={note.id} className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 space-y-1">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-neutral-900">{note.author}</span>
                        <span className="font-mono text-neutral-400">{note.timestamp}</span>
                      </div>
                      <p className="text-xs text-neutral-700 leading-relaxed">
                        {note.text}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Add Note Input */}
                <div className="pt-2 flex flex-col sm:flex-row gap-2">
                  <select
                    value={noteAuthor}
                    onChange={(e) => setNoteAuthor(e.target.value)}
                    className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-300 rounded-lg text-xs text-neutral-800 shrink-0"
                  >
                    <option value="José Rafael Vásquez">José Rafael Vásquez (Director)</option>
                    <option value="María Fernández">María Fernández (Socia)</option>
                    <option value="Ricardo Salas">Ricardo Salas (Socio)</option>
                    <option value="Carlos Bermúdez">Carlos Bermúdez (Regulatorio)</option>
                    <option value="Ana Rivas">Ana Rivas (Propiedad Intelectual)</option>
                  </select>

                  <input
                    type="text"
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    placeholder="Escribir nota de llamada, reunión o términos acordados..."
                    className="flex-1 px-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-lg text-xs text-neutral-900 focus:outline-none focus:bg-white"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleAddNote(selectedLead.id);
                    }}
                  />

                  <button
                    type="button"
                    onClick={() => handleAddNote(selectedLead.id)}
                    className="px-4 py-1.5 bg-neutral-900 text-white rounded-lg text-xs font-semibold hover:bg-neutral-800 transition-colors shrink-0"
                  >
                    Guardar Nota
                  </button>
                </div>
              </div>

            </div>

            {/* Dossier Footer */}
            <div className="p-4 sm:p-6 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between">
              <span className="text-xs text-neutral-500">
                BinLegal · Panel de Gestión PYME
              </span>
              <button
                onClick={() => setSelectedLead(null)}
                className="px-4 py-2 text-xs font-semibold bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 transition-colors"
              >
                Cerrar Expediente
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ADD MANUAL LEAD MODAL */}
      {showAddLeadModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/65 backdrop-blur-xs animate-in fade-in overflow-y-auto"
          role="dialog"
          aria-modal="true"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowAddLeadModal(false);
          }}
        >
          <div 
            className="bg-white w-full max-w-xl rounded-2xl border border-neutral-200 shadow-2xl p-6 sm:p-8 max-h-[92dvh] overflow-y-auto relative animate-in zoom-in-95 my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between pb-4 border-b border-neutral-100 mb-5">
              <div>
                <h3 className="text-xl font-display font-extrabold text-neutral-950">
                  Registrar Nuevo Prospecto (Lead Manual)
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Para llamadas comerciales, eventos o networking directo.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddLeadModal(false)}
                className="w-8 h-8 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-neutral-950 flex items-center justify-center transition-colors"
                aria-label="Cerrar modal"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            <form onSubmit={handleSaveManualLead} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Nombre completo *</label>
                  <input
                    type="text"
                    required
                    value={newFullName}
                    onChange={(e) => setNewFullName(e.target.value)}
                    placeholder="Ej. Gustavo Páez"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Empresa / Proyecto *</label>
                  <input
                    type="text"
                    required
                    value={newCompany}
                    onChange={(e) => setNewCompany(e.target.value)}
                    placeholder="Ej. Páez & Co Logística"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Correo electrónico *</label>
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="gustavo@paez.com"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Teléfono / WhatsApp</label>
                  <input
                    type="tel"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="+58 412 111 2233"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">Etapa de la empresa</label>
                <select
                  value={newStage}
                  onChange={(e) => setNewStage(e.target.value as BusinessStage)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                >
                  <option value="Idea / Pre-lanzamiento">Idea / Pre-lanzamiento</option>
                  <option value="Recién constituida">Recién constituida</option>
                  <option value="En crecimiento">En crecimiento</option>
                  <option value="Consolidada">Consolidada</option>
                </select>
              </div>

              {/* Segmented Sector Selector (Max 3 + Otro) */}
              <div className="pt-1 pb-1">
                <SectorSelector
                  compact={true}
                  selectedSectors={newSelectedSectors}
                  otherText={newOtherSectorText}
                  onSelectionChange={(sectors, other) => {
                    setNewSelectedSectors(sectors);
                    setNewOtherSectorText(other);
                  }}
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">Notas iniciales</label>
                <textarea
                  rows={3}
                  value={newSituation}
                  onChange={(e) => setNewSituation(e.target.value)}
                  placeholder="Detalles de la conversación..."
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none focus:bg-white"
                />
              </div>

              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddLeadModal(false)}
                  className="px-4 py-2 font-medium text-neutral-600 hover:text-neutral-900"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-semibold text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors shadow-xs"
                >
                  Guardar en Pipeline
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT PROCESS STATUS MODAL FOR ADMIN */}
      {selectedProcessToEdit && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white w-full max-w-lg rounded-2xl border border-neutral-200 shadow-2xl p-6 sm:p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-display font-extrabold text-neutral-950">
                  Actualizar Estatus de Expediente
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {selectedProcessToEdit.title} ({selectedProcessToEdit.companyName || selectedProcessToEdit.clientName})
                </p>
              </div>
              <button
                onClick={() => setSelectedProcessToEdit(null)}
                className="p-1.5 text-neutral-400 hover:text-neutral-900 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.target as any;
                const newSt = form.status.value as ProcessStatus;
                const newProg = Number(form.progress.value);
                const newMilestone = form.milestone.value;
                onUpdateProcessStatus?.(selectedProcessToEdit.id, newSt, newProg, newMilestone);
                setSelectedProcessToEdit(null);
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">Fase del Trámite</label>
                <select
                  name="status"
                  defaultValue={selectedProcessToEdit.status}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none"
                >
                  <option value="recaudos">1. Recaudos (Consignación de recaudos)</option>
                  <option value="redaccion">2. Redacción (En redacción por equipo legal)</option>
                  <option value="tramite_publico">3. Ente Público (SAPI / Registro / Notaría)</option>
                  <option value="revision">4. Revisión (Revisión y visto bueno final)</option>
                  <option value="completado">5. Finalizado (Trámite entregado y blindado)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  Porcentaje de Avance (0 - 100%)
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    name="progress"
                    defaultValue={selectedProcessToEdit.progress}
                    onChange={(e) => {
                      const display = document.getElementById('progress-val');
                      if (display) display.innerText = `${e.target.value}%`;
                    }}
                    className="flex-1 accent-neutral-900"
                  />
                  <span id="progress-val" className="font-mono font-bold text-sm w-12 text-right">
                    {selectedProcessToEdit.progress}%
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">Próximo Hito para el Cliente</label>
                <input
                  type="text"
                  name="milestone"
                  defaultValue={selectedProcessToEdit.nextMilestone}
                  placeholder="Ej. Revisión y entrega de borrador v2..."
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900 focus:outline-none"
                />
              </div>

              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedProcessToEdit(null)}
                  className="px-4 py-2 font-medium text-neutral-600 hover:text-neutral-900"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-semibold text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors shadow-xs"
                >
                  Guardar y Sincronizar en Vivo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
