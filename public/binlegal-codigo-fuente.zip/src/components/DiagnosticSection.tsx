import React, { useState, useEffect } from 'react';
import { BusinessStage, LegalArea, Lead, RiskItem } from '../types';
import { calculateDiagnosisRisk } from '../data/initialData';
import { SectorSelector } from './SectorSelector';
import { 
  CheckCircle2, 
  ArrowRight, 
  Check, 
  RotateCcw, 
  ShieldCheck, 
  Clock 
} from 'lucide-react';
import { trackDiagnosticStart, trackDiagnosticComplete, trackClick } from '../lib/analytics';

interface DiagnosticSectionProps {
  onNewLeadCreated: (lead: Lead) => void;
  preselectedArea?: LegalArea | null;
}

const BUSINESS_STAGES: BusinessStage[] = [
  'Idea / Pre-lanzamiento',
  'Recién constituida',
  'En crecimiento',
  'Consolidada'
];

const LEGAL_AREAS: LegalArea[] = [
  'Corporativo',
  'Propiedad Intelectual',
  'Regulatorio',
  'Laboral',
  'Contratos',
  'Mediación'
];

export const DiagnosticSection: React.FC<DiagnosticSectionProps> = ({
  onNewLeadCreated,
  preselectedArea
}) => {
  const [stage, setStage] = useState<BusinessStage>('Recién constituida');
  const [selectedAreas, setSelectedAreas] = useState<LegalArea[]>(['Corporativo', 'Propiedad Intelectual']);
  
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [selectedSectors, setSelectedSectors] = useState<string[]>(['Tecnología & Software']);
  const [otherSectorText, setOtherSectorText] = useState('');
  const [situation, setSituation] = useState('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<{
    lead: Lead;
    items: RiskItem[];
    score: number;
    summary: string;
  } | null>(null);

  // Sync preselected area from services if triggered
  useEffect(() => {
    if (preselectedArea && !selectedAreas.includes(preselectedArea)) {
      setSelectedAreas(prev => [...prev, preselectedArea]);
    }
  }, [preselectedArea]);

  const toggleArea = (area: LegalArea) => {
    if (selectedAreas.includes(area)) {
      if (selectedAreas.length > 1) {
        setSelectedAreas(selectedAreas.filter(a => a !== area));
      }
    } else {
      setSelectedAreas([...selectedAreas, area]);
    }
  };

  const getFormattedIndustry = () => {
    const list = selectedSectors.map(s => {
      if (s === 'Otro') {
        return otherSectorText.trim() ? `Otro: ${otherSectorText.trim()}` : 'Otro';
      }
      return s;
    });
    return list.join(', ');
  };

  const validateForm = () => {
    const errs: Record<string, string> = {};
    if (!fullName.trim()) errs.fullName = 'Ingresa tu nombre completo';
    if (!email.trim()) {
      errs.email = 'Ingresa tu correo de contacto';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errs.email = 'Ingresa un correo electrónico válido';
    }
    if (!company.trim()) errs.company = 'Ingresa el nombre de tu empresa o proyecto';
    
    if (selectedSectors.length === 0) {
      errs.industry = 'Selecciona al menos 1 sector que aplique a tu empresa (máximo 3)';
    } else if (selectedSectors.includes('Otro') && !otherSectorText.trim()) {
      errs.industry = 'Por favor especifica el nombre de tu sector en el campo "Otro"';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    const formattedIndustry = getFormattedIndustry();

    setTimeout(() => {
      const calculation = calculateDiagnosisRisk(stage, selectedAreas, company, formattedIndustry);
      
      const newLead: Lead = {
        id: `lead-${Date.now()}`,
        fullName,
        email,
        phone: phone || undefined,
        company,
        industry: formattedIndustry,
        stage,
        areasOfInterest: selectedAreas,
        notes: situation || undefined,
        status: 'nuevo_lead',
        createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        calculatedRiskScore: calculation.score,
        riskSummary: calculation.summary,
        riskItems: calculation.items,
        internalNotes: [
          {
            id: `note-${Date.now()}`,
            author: 'Sistema BinLegal',
            text: `Diagnóstico generado automáticamente. Riesgo evaluado: ${calculation.score}/100. Etapa: ${stage}. Áreas prioritarias: ${selectedAreas.join(', ')}.`,
            timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
          }
        ]
      };

      trackDiagnosticComplete(formattedIndustry, calculation.score, calculation.items.length);
      onNewLeadCreated(newLead);
      setDiagnosisResult({
        lead: newLead,
        items: calculation.items,
        score: calculation.score,
        summary: calculation.summary
      });
      setIsSubmitting(false);
    }, 600);
  };

  const handleReset = () => {
    trackClick('diagnostico', 'reiniciar_diagnostico');
    setDiagnosisResult(null);
    setSituation('');
  };

  return (
    <section id="diagnostico" className="py-10 sm:py-12 lg:py-14 bg-slate-50/60 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-6 sm:mb-8">
          <div className="text-[11px] sm:text-xs font-semibold tracking-wider text-[#0071ce] uppercase mb-1.5 sm:mb-2">
            06 — Gratis
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold text-slate-950 tracking-tight mb-2 text-balance">
            Diagnóstico Legal Gratuito.
          </h2>
          <p className="text-xs sm:text-sm lg:text-base text-slate-600 leading-relaxed">
            Cuéntanos sobre tu negocio y te devolvemos un mapa de riesgos y oportunidades legales, sin costo y sin compromiso.
          </p>
        </div>

        {!diagnosisResult ? (
          /* The Interactive Step-by-Step Diagnostic Form */
          <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200/90 p-4 sm:p-6 lg:p-7 max-w-4xl shadow-sm">
            
            {/* Step 1: Etapa del Negocio */}
            <div className="mb-5 sm:mb-6">
              <label className="block text-xs sm:text-sm font-semibold text-slate-900 mb-1">
                1. Etapa del negocio
              </label>
              <p className="text-[11px] sm:text-xs text-slate-500 mb-3">
                Selecciona la fase en la que se encuentra actualmente tu proyecto.
              </p>
              
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-2.5">
                {BUSINESS_STAGES.map((s) => {
                  const isSelected = stage === s;
                  return (
                    <button
                      type="button"
                      key={s}
                      onClick={() => setStage(s)}
                      className={`p-3 rounded-lg border text-left transition-all shadow-2xs hover:shadow-xs cursor-pointer active:scale-95 ${
                        isSelected
                          ? 'bg-[#0071ce] text-white border-[#0071ce] shadow-xs'
                          : 'bg-white text-slate-800 border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <div className="text-[10px] font-bold uppercase tracking-wider mb-0.5 opacity-75">
                        {isSelected ? 'Seleccionada' : 'Fase'}
                      </div>
                      <div className="text-xs sm:text-sm font-semibold leading-tight">
                        {s}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Áreas de Interés */}
            <div className="mb-5 sm:mb-6">
              <label className="block text-xs sm:text-sm font-semibold text-neutral-900 mb-1">
                2. Áreas de interés (puedes marcar varias)
              </label>
              <p className="text-[11px] sm:text-xs text-neutral-500 mb-3">
                ¿Qué aspectos legales preocupan más o deseas blindar?
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
                {LEGAL_AREAS.map((area) => {
                  const isChecked = selectedAreas.includes(area);
                  return (
                    <button
                      type="button"
                      key={area}
                      onClick={() => toggleArea(area)}
                      className={`p-2.5 sm:p-3 rounded-lg border text-left transition-all flex items-center justify-between cursor-pointer active:scale-95 ${
                        isChecked
                          ? 'bg-[#0071ce] text-white border-[#0071ce] shadow-2xs'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <span className="text-xs sm:text-sm font-medium">{area}</span>
                      <div className={`w-3.5 h-3.5 rounded flex items-center justify-center shrink-0 ml-1.5 ${
                        isChecked ? 'bg-white text-neutral-900' : 'border border-neutral-300'
                      }`}>
                        {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Datos de Contacto y Empresa */}
            <div className="mb-5 sm:mb-6 pt-5 sm:pt-6 border-t border-neutral-200/80">
              <label className="block text-xs sm:text-sm font-semibold text-neutral-900 mb-3">
                3. Datos de contacto y de tu empresa
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ej. Sofía Valero"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                  {errors.fullName && <p className="text-[11px] text-red-600 mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Correo electrónico *
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="sofia@tuempresa.com"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                  {errors.email && <p className="text-[11px] text-red-600 mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Empresa o nombre del proyecto *
                  </label>
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Ej. Nexo Store"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                  {errors.company && <p className="text-[11px] text-red-600 mt-1">{errors.company}</p>}
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Teléfono / WhatsApp (opcional)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+58 412 000 0000"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                </div>

                {/* Sector / Industria Selector (Max 3 + Otro) */}
                <div className="sm:col-span-2 pt-1 pb-1">
                  <SectorSelector
                    selectedSectors={selectedSectors}
                    otherText={otherSectorText}
                    onSelectionChange={(sectors, other) => {
                      setSelectedSectors(sectors);
                      setOtherSectorText(other);
                      if (errors.industry) {
                        setErrors(prev => {
                          const next = { ...prev };
                          delete next.industry;
                          return next;
                        });
                      }
                    }}
                    error={errors.industry}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Cuéntanos brevemente tu situación (opcional)
                  </label>
                  <textarea
                    rows={2}
                    value={situation}
                    onChange={(e) => setSituation(e.target.value)}
                    placeholder="¿Tienes socios? ¿Firmaste algún contrato reciente? ¿Estás por lanzar tu marca?"
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-900"
                  />
                </div>
              </div>
            </div>

            {/* Submission Action */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3.5 border-t border-neutral-200">
              <div className="flex items-center gap-1.5 text-[11px] text-neutral-500">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-700 shrink-0" />
                <span>Tus datos son tratados bajo estricto secreto profesional.</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#0071ce] hover:bg-[#0060b0] disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer active:scale-95"
              >
                {isSubmitting ? (
                  <span>Calculando mapa de riesgos...</span>
                ) : (
                  <>
                    <span>Solicitar diagnóstico gratuito</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>

          </form>
        ) : (
          /* Generated Interactive Risk & Opportunity Map */
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 sm:p-6 lg:p-7 max-w-4xl shadow-sm animate-in fade-in">
            
            {/* Top Score Bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2 text-[11px] text-neutral-500 font-mono mb-1">
                  <span>Diagnóstico BinLegal #{diagnosisResult.lead.id.slice(-6)}</span>
                  <span>·</span>
                  <span>{diagnosisResult.lead.createdAt}</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-display font-extrabold text-neutral-950 leading-tight">
                  Mapa de Riesgos: {diagnosisResult.lead.company}
                </h3>
                <p className="text-xs text-neutral-600 mt-0.5">
                  Preparado para <strong className="text-neutral-900">{diagnosisResult.lead.fullName}</strong> ({diagnosisResult.lead.industry} · {diagnosisResult.lead.stage})
                </p>
              </div>

              {/* Tabular Score Card */}
              <div className="flex items-center gap-3 bg-neutral-50 p-3 rounded-lg border border-neutral-200 shrink-0">
                <div>
                  <div className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Índice de Exposición
                  </div>
                  <div className="text-2xl font-display font-extrabold text-neutral-950 tabular-nums">
                    {diagnosisResult.score} <span className="text-xs font-normal text-neutral-400">/ 100</span>
                  </div>
                </div>
                <div className="w-2 h-8 rounded-full bg-[#0071ce]" />
              </div>
            </div>

            {/* Summary Message */}
            <div className="my-4 p-3.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs sm:text-sm text-neutral-700 leading-relaxed">
              <div className="font-semibold text-neutral-900 mb-1 text-[11px] uppercase tracking-wider">
                Dictamen Preliminar:
              </div>
              {diagnosisResult.summary}
            </div>

            {/* Prioritized Risk Items */}
            <div className="space-y-3 my-5">
              <h4 className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider">
                Hallazgos Críticos ({diagnosisResult.items.length})
              </h4>

              {diagnosisResult.items.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-lg border border-neutral-200 bg-white space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-neutral-900 font-mono">
                        {item.area}
                      </span>
                      <span className="text-neutral-300">·</span>
                      <span className={`text-[11px] font-semibold ${
                        item.level === 'Alto' ? 'text-red-700' : 'text-amber-700'
                      }`}>
                        Riesgo {item.level}
                      </span>
                    </div>
                  </div>

                  <h5 className="text-xs sm:text-sm font-bold text-neutral-950">
                    {item.title}
                  </h5>

                  <p className="text-xs text-neutral-600 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="pt-1.5 flex items-start gap-1.5 text-xs text-neutral-900 font-medium">
                    <span className="text-neutral-500 shrink-0">Acción recomendada:</span>
                    <span>{item.actionRequired}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Next Steps & CTA to connect with José Rafael */}
            <div className="pt-4 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-neutral-500">
                Tu diagnóstico ha quedado registrado en nuestro sistema de atención preferencial.
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={handleReset}
                  data-track-section="diagnostico_resultado"
                  data-track-name="btn_nuevo_diagnostico"
                  className="w-full sm:w-auto px-3.5 py-2 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Nuevo Diagnóstico</span>
                </button>

                <a
                  href="#contacto"
                  onClick={() => trackClick('diagnostico_resultado', 'coordinar_sesion')}
                  data-track-section="diagnostico_resultado"
                  data-track-name="cta_coordinar_sesion"
                  className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-white bg-[#0071ce] hover:bg-[#0060b0] rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs whitespace-nowrap"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Coordinar Sesión</span>
                </a>
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};
