import React, { useState, useEffect } from 'react';
import { Analytics } from '@vercel/analytics/react';
import { SpeedInsights } from '@vercel/speed-insights/react';
import { initGlobalClickTracking, trackNavigation, trackAuthAction } from './lib/analytics';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { WhySection } from './components/WhySection';
import { HowSection } from './components/HowSection';
import { TeamSection } from './components/TeamSection';
import { BlogSection } from './components/BlogSection';
import { DiagnosticSection } from './components/DiagnosticSection';
import { EcosystemSection } from './components/EcosystemSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AdminCRM } from './components/AdminCRM';
import { ClientPortal } from './components/ClientPortal';
import { AuthModal } from './components/AuthModal';
import { AffiliateBanner } from './components/AffiliateBanner';
import { ShareModal } from './components/ShareModal';
import { doc, setDoc, collection, onSnapshot } from 'firebase/firestore';
import { db } from './lib/firebase';

import { 
  Lead, 
  LeadStatus, 
  LegalArea, 
  EcosystemStartup, 
  ForumPost, 
  LegalProcess, 
  ProcessStatus 
} from './types';
import { 
  INITIAL_LEADS, 
  INITIAL_ECOSYSTEM_STARTUPS, 
  INITIAL_FORUM_POSTS 
} from './data/initialData';
import { processService, INITIAL_DEMO_PROCESSES } from './services/processService';

function MainAppContent() {
  const { currentUser, userProfile, isAdmin } = useAuth();
  const [currentView, setCurrentView] = useState<'landing' | 'admin' | 'ecosystem' | 'portal'>('landing');
  const [activeSection, setActiveSection] = useState<string>('inicio');
  const [preselectedArea, setPreselectedArea] = useState<LegalArea | null>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'newsletter'>('login');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  useEffect(() => {
    // Automatically capture all data-track-* clicks across the whole page
    const cleanupTracking = initGlobalClickTracking();
    return () => cleanupTracking();
  }, []);

  const handleOpenAuth = (mode: 'login' | 'register' | 'newsletter' = 'login') => {
    trackAuthAction('open_modal', { mode });
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  // Persistent Leads State (CRM & Diagnóstico)
  const [leads, setLeads] = useState<Lead[]>(() => {
    try {
      const saved = localStorage.getItem('binlegal_leads_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_LEADS;
  });

  // Persistent Processes State (Syncing with Firestore & fallback memory)
  const [processes, setProcesses] = useState<LegalProcess[]>(INITIAL_DEMO_PROCESSES);

  // Persistent Ecosystem Startups
  const [startups, setStartups] = useState<EcosystemStartup[]>(() => {
    try {
      const saved = localStorage.getItem('binlegal_startups_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_ECOSYSTEM_STARTUPS;
  });

  // Persistent Forum Posts
  const [posts, setPosts] = useState<ForumPost[]>(() => {
    try {
      const saved = localStorage.getItem('binlegal_posts_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_FORUM_POSTS;
  });

  // Real-time Firestore subscription for legal and administrative processes
  useEffect(() => {
    let unsubscribe: () => void;
    if (isAdmin || currentView === 'admin') {
      unsubscribe = processService.subscribeAllProcesses((updated) => {
        if (updated.length > 0) setProcesses(updated);
      });
    } else if (currentUser) {
      unsubscribe = processService.subscribeUserProcesses(currentUser.uid, (updated) => {
        if (updated.length > 0) setProcesses(updated);
      });
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [currentUser, isAdmin, currentView]);

  // Real-time Firestore subscription for leads (CRM / José Rafael Vásquez)
  useEffect(() => {
    let unsubscribe: () => void;
    if (isAdmin || currentView === 'admin') {
      try {
        unsubscribe = onSnapshot(collection(db, 'leads'), (snapshot) => {
          if (!snapshot.empty) {
            const firestoreLeads = snapshot.docs.map(d => d.data() as Lead);
            setLeads(prev => {
              const map = new Map<string, Lead>();
              prev.forEach(l => map.set(l.id, l));
              firestoreLeads.forEach(l => map.set(l.id, l));
              return Array.from(map.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
            });
          }
        }, (err) => {
          console.warn('Firestore leads subscription note:', err);
        });
      } catch (e) {
        console.warn(e);
      }
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isAdmin, currentView]);

  // Sync leads, startups, posts to local storage
  useEffect(() => {
    localStorage.setItem('binlegal_leads_v1', JSON.stringify(leads));
  }, [leads]);

  useEffect(() => {
    localStorage.setItem('binlegal_startups_v1', JSON.stringify(startups));
  }, [startups]);

  useEffect(() => {
    localStorage.setItem('binlegal_posts_v1', JSON.stringify(posts));
  }, [posts]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Active section scroll spy for landing page
  useEffect(() => {
    if (currentView !== 'landing') {
      setActiveSection(currentView);
      return;
    }

    const sectionIds = ['inicio', 'que-hacemos', 'por-que', 'como', 'equipo', 'blog', 'diagnostico', 'contacto'];
    const elements = sectionIds
      .map(id => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];

    if (elements.length === 0) return;

    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter(e => e.isIntersecting);
      if (visible.length > 0) {
        visible.sort((a, b) => Math.abs(a.boundingClientRect.top) - Math.abs(b.boundingClientRect.top));
        setActiveSection(visible[0].target.id);
      }
    }, {
      rootMargin: '-70px 0px -40% 0px',
      threshold: [0, 0.2, 0.5]
    });

    elements.forEach(el => observer.observe(el));

    return () => {
      observer.disconnect();
    };
  }, [currentView]);

  const handleNavigate = (view: 'landing' | 'admin' | 'ecosystem' | 'portal', sectionId?: string) => {
    trackNavigation(sectionId || view, 'navigation');
    setCurrentView(view);
    if (sectionId) {
      setActiveSection(sectionId);
    } else {
      setActiveSection(view === 'landing' ? 'inicio' : view);
    }

    if (sectionId && (view === 'landing' || view === 'ecosystem')) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 50);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSelectAreaForDiagnosis = (area: LegalArea) => {
    setPreselectedArea(area);
    handleNavigate('landing', 'diagnostico');
    showNotification(`Área "${area}" preseleccionada en tu diagnóstico legal.`);
  };

  const handleNewLeadCreated = async (newLead: Lead) => {
    setLeads(prev => [newLead, ...prev]);
    showNotification(`¡Diagnóstico para "${newLead.company}" procesado! Registrado en CRM.`);
    try {
      await setDoc(doc(db, 'leads', newLead.id), newLead);
    } catch (err) {
      console.warn('Could not save lead to Firestore:', err);
    }
  };

  const handleUpdateLeadStatus = async (leadId: string, newStatus: LeadStatus) => {
    setLeads(prev => prev.map(lead => {
      if (lead.id === leadId) {
        return { ...lead, status: newStatus };
      }
      return lead;
    }));
    showNotification('Estado del prospecto actualizado en el pipeline.');
    try {
      await setDoc(doc(db, 'leads', leadId), { status: newStatus }, { merge: true });
    } catch (err) {
      console.warn('Firestore update status:', err);
    }
  };

  const handleAddInternalNote = async (leadId: string, noteText: string, author: string) => {
    const newNote = {
      id: `note-${Date.now()}`,
      author,
      text: noteText,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };
    setLeads(prev => prev.map(lead => {
      if (lead.id === leadId) {
        return {
          ...lead,
          internalNotes: [...lead.internalNotes, newNote]
        };
      }
      return lead;
    }));
    showNotification('Nota interna guardada.');
  };

  const handleAddManualLead = async (manualLead: Lead) => {
    setLeads(prev => [manualLead, ...prev]);
    showNotification(`Lead "${manualLead.company}" registrado en el pipeline.`);
    try {
      await setDoc(doc(db, 'leads', manualLead.id), manualLead);
    } catch (err) {
      console.warn('Could not save manual lead to Firestore:', err);
    }
  };

  const handleUpdateProcessStatus = async (
    processId: string, 
    status: ProcessStatus, 
    progress: number, 
    milestone?: string
  ) => {
    try {
      await processService.updateProcessStatus(processId, status, progress, milestone);
      // Local optimistic update
      setProcesses(prev => prev.map(p => {
        if (p.id === processId) {
          return {
            ...p,
            status,
            progress,
            nextMilestone: milestone || p.nextMilestone,
            updatedAt: new Date().toISOString().slice(0, 10)
          };
        }
        return p;
      }));
      showNotification('Estatus de expediente actualizado y sincronizado en vivo.');
    } catch (err) {
      console.error(err);
      showNotification('Error al actualizar estatus.');
    }
  };

  const handleAddForumPost = (post: ForumPost) => {
    setPosts(prev => [post, ...prev]);
    showNotification('Pregunta publicada en el foro del ecosistema.');
  };

  const handleAddForumReply = (postId: string, text: string, author: string, company: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          replies: [
            ...post.replies,
            {
              id: `reply-${Date.now()}`,
              author,
              role: 'Miembro Comunidad',
              company,
              content: text,
              createdAt: 'Hace un momento'
            }
          ]
        };
      }
      return post;
    }));
    showNotification('Respuesta agregada al hilo.');
  };

  const unreadCount = leads.filter(l => l.status === 'nuevo_lead').length;

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-neutral-900 flex flex-col font-sans selection:bg-neutral-900 selection:text-white">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 left-4 sm:left-auto z-50 bg-neutral-950 text-white px-4 py-3 rounded-xl shadow-lg border border-neutral-800 text-xs font-medium flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2 max-w-sm mx-auto sm:mx-0">
          <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
          <span className="flex-1">{notification}</span>
        </div>
      )}

      {/* Auth Modal with dynamic mode (login, register, or newsletter) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        defaultMode={authModalMode}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={() => {
          showNotification('¡Sesión iniciada con éxito!');
          handleNavigate('portal');
        }}
      />

      {/* Share Platform Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Persistent Affiliate & Newsletter Call-to-Action (Always accessible when not logged in) */}
      {currentView !== 'admin' && (
        <AffiliateBanner onOpenAuth={handleOpenAuth} />
      )}

      {/* Main View Router */}
      {currentView === 'admin' ? (
        <AdminCRM
          leads={leads}
          processes={processes}
          onUpdateLeadStatus={handleUpdateLeadStatus}
          onAddInternalNote={handleAddInternalNote}
          onAddManualLead={handleAddManualLead}
          onUpdateProcessStatus={handleUpdateProcessStatus}
          onBackToLanding={() => handleNavigate('landing')}
        />
      ) : currentView === 'portal' ? (
        <>
          <Navbar
            currentView={currentView}
            activeSection={activeSection}
            onNavigate={handleNavigate}
            unreadLeadsCount={unreadCount}
            onOpenAuth={handleOpenAuth}
            onOpenShare={() => setIsShareModalOpen(true)}
          />

          <ClientPortal
            processes={processes}
            onBackToLanding={() => handleNavigate('landing')}
          />

          <Footer
            onNavigateSection={(sectionId) => handleNavigate('landing', sectionId)}
            onOpenAdmin={() => handleNavigate('admin')}
          />
        </>
      ) : (
        <>
          <Navbar
            currentView={currentView}
            activeSection={activeSection}
            onNavigate={handleNavigate}
            unreadLeadsCount={unreadCount}
            onOpenAuth={handleOpenAuth}
            onOpenShare={() => setIsShareModalOpen(true)}
          />

          <main className="flex-1">
            {currentView === 'landing' ? (
              <>
                <HeroSection
                  onStartDiagnosis={() => handleNavigate('landing', 'diagnostico')}
                  onExploreServices={() => handleNavigate('landing', 'que-hacemos')}
                />

                <ServicesSection
                  onSelectAreaForDiagnosis={handleSelectAreaForDiagnosis}
                />

                <WhySection />

                <HowSection
                  onStartDiagnosis={() => handleNavigate('landing', 'diagnostico')}
                />

                <TeamSection />

                <BlogSection
                  onOpenAuth={handleOpenAuth}
                />

                <DiagnosticSection
                  onNewLeadCreated={handleNewLeadCreated}
                  preselectedArea={preselectedArea}
                />

                <EcosystemSection
                  startups={startups}
                  posts={posts}
                  onAddPost={handleAddForumPost}
                  onAddReply={handleAddForumReply}
                />

                <ContactSection
                  onOpenAdmin={() => handleNavigate('admin')}
                  onOpenAuth={handleOpenAuth}
                />
              </>
            ) : (
              // Dedicated Ecosystem & Networking view
              <div className="py-8">
                <EcosystemSection
                  startups={startups}
                  posts={posts}
                  onAddPost={handleAddForumPost}
                  onAddReply={handleAddForumReply}
                />
              </div>
            )}
          </main>

          <Footer
            onNavigateSection={(sectionId) => handleNavigate('landing', sectionId)}
            onOpenAdmin={() => handleNavigate('admin')}
          />
        </>
      )}

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
      <Analytics />
      <SpeedInsights />
    </AuthProvider>
  );
}
