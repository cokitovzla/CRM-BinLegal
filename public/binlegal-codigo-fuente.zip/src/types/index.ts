export type BusinessStage = 
  | 'Idea / Pre-lanzamiento'
  | 'Recién constituida'
  | 'En crecimiento'
  | 'Consolidada';

export type LegalArea = 
  | 'Corporativo'
  | 'Propiedad Intelectual'
  | 'Regulatorio'
  | 'Laboral'
  | 'Contratos'
  | 'Mediación'
  | 'Negociación y mediación';

export type LeadStatus = 
  | 'nuevo_lead'
  | 'diagnostico_enviado'
  | 'sesion_programada'
  | 'propuesta_presentada'
  | 'cliente_activo';

export type ProcessStatus = 
  | 'recaudos'
  | 'redaccion'
  | 'tramite_publico'
  | 'revision'
  | 'completado';

export interface ProcessDocument {
  name: string;
  category: string;
  date: string;
  status: 'aprobado' | 'en_revision' | 'pendiente';
}

export interface ProcessMilestone {
  date: string;
  title: string;
  note: string;
}

export interface LegalProcess {
  id: string;
  userId: string;
  clientEmail: string;
  clientName?: string;
  companyName?: string;
  title: string;
  category: 'Corporativo' | 'Propiedad Intelectual' | 'Regulatorio' | 'Laboral' | 'Administrativo & Notarial' | 'Mediación';
  status: ProcessStatus;
  progress: number;
  assignedLawyer: string;
  nextMilestone: string;
  targetDate: string;
  documents?: ProcessDocument[];
  milestones?: ProcessMilestone[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  userId: string;
  email: string;
  displayName: string;
  username?: string;
  companyName?: string;
  industry?: string;
  sectors?: string[];
  isSubscribedNewsletter?: boolean;
  role: 'client' | 'admin';
  createdAt: string;
}

export interface InternalNote {
  id: string;
  author: string;
  text: string;
  timestamp: string;
}

export interface RiskItem {
  area: string;
  level: 'Alto' | 'Medio' | 'Bajo';
  title: string;
  description: string;
  actionRequired: string;
}

export interface Lead {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  company: string;
  industry: string;
  stage: BusinessStage;
  areasOfInterest: LegalArea[];
  notes?: string;
  status: LeadStatus;
  createdAt: string;
  calculatedRiskScore: number; // 0 - 100
  riskSummary: string;
  riskItems: RiskItem[];
  internalNotes: InternalNote[];
}

export interface ServiceDetail {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  shortDescription: string;
  fullDescription: string;
  keyDeliverables: string[];
  commonRisks: string[];
  idealStage: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  specialty: string;
  experience: string;
  email: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  date: string;
  readTime: string;
  excerpt: string;
  content: string[];
  author: string;
}

export interface EcosystemStartup {
  id: string;
  name: string;
  founder: string;
  sector: string;
  stage: BusinessStage;
  description: string;
  synergies: string[];
  verifiedClient: boolean;
  city: string;
}

export interface ForumPost {
  id: string;
  author: string;
  authorRole: string;
  company: string;
  category: 'Rondas de Inversión' | 'Contratos y Proveedores' | 'Permisología y Marcas' | 'Alianzas Comerciales';
  title: string;
  content: string;
  createdAt: string;
  likes: number;
  replies: Array<{
    id: string;
    author: string;
    role: string;
    company: string;
    content: string;
    createdAt: string;
  }>;
}
